import { useMemo } from 'react';
import { calcTotal, calcPaid, fmt, fmtShort, today } from '../data';

export default function Payments({ invoices, customers }) {
  const allPayments = useMemo(() =>
    (invoices || []).flatMap(inv => inv.payments.map(p => ({
      ...p, invoiceId: inv.id,
      customerName: (customers || []).find(c => c.id === inv.customerId)?.name || "Unknown"
    }))).sort((a, b) => b.date.localeCompare(a.date)),
    [invoices, customers]
  );

  const totalCollected   = allPayments.reduce((s, p) => s + p.amount, 0);
  const byMethod         = allPayments.reduce((acc, p) => { acc[p.method] = (acc[p.method] || 0) + p.amount; return acc; }, {});
  const outstanding      = (invoices || []).filter(inv => calcPaid(inv.payments) < calcTotal(inv.items));
  const totalOutstanding = outstanding.reduce((s, inv) => s + (calcTotal(inv.items) - calcPaid(inv.payments)), 0);

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Payments</h1>
        <p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Full payment history and outstanding collections</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 24 }}>
        <div className="stat-card" style={{ borderLeft: "4px solid #059669" }}>
          <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 700, textTransform: "uppercase" }}>Total Collected</div>
          <div style={{ fontSize: 26, fontWeight: 800, color: "#0f172a", fontFamily: "'Syne',sans-serif", marginTop: 6 }}>{fmtShort(totalCollected)}</div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{allPayments.length} transactions</div>
        </div>
        <div className="stat-card" style={{ borderLeft: "4px solid #ef4444" }}>
          <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 700, textTransform: "uppercase" }}>Outstanding</div>
          <div style={{ fontSize: 26, fontWeight: 800, color: "#0f172a", fontFamily: "'Syne',sans-serif", marginTop: 6 }}>{fmtShort(totalOutstanding)}</div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{outstanding.length} invoices pending</div>
        </div>
        <div className="stat-card" style={{ borderLeft: "4px solid #0077b6" }}>
          <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 700, textTransform: "uppercase", marginBottom: 10 }}>By Method</div>
          {Object.entries(byMethod).map(([m, v]) => (
            <div key={m} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 5 }}>
              <span style={{ color: "#64748b" }}>{m}</span><span style={{ fontWeight: 700 }}>{fmtShort(v)}</span>
            </div>
          ))}
          {Object.keys(byMethod).length === 0 && <div style={{ fontSize: 13, color: "#94a3b8" }}>No payments yet</div>}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20 }}>
        <div>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>Payment History</h3>
          <div className="card">
            <table>
              <thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Amount</th><th>Method</th><th>Ref</th></tr></thead>
              <tbody>
                {allPayments.length === 0 && <tr><td colSpan={6} style={{ textAlign: "center", color: "#94a3b8", padding: 30 }}>No payments yet</td></tr>}
                {allPayments.map((p, i) => (
                  <tr key={i}>
                    <td>{p.date}</td>
                    <td style={{ fontWeight: 600, color: "#0077b6" }}>{p.invoiceId}</td>
                    <td>{p.customerName}</td>
                    <td style={{ fontWeight: 700, color: "#059669" }}>{fmt(p.amount)}</td>
                    <td><span className="tag" style={{ background: "#dbeafe", color: "#1e40af" }}>{p.method}</span></td>
                    <td style={{ color: "#64748b", fontSize: 12 }}>{p.ref || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 14 }}>Outstanding Collections</h3>
          <div className="card">
            <table>
              <thead><tr><th>Invoice</th><th>Customer</th><th>Balance</th><th>Due</th></tr></thead>
              <tbody>
                {outstanding.length === 0 && <tr><td colSpan={4} style={{ textAlign: "center", color: "#94a3b8", padding: 30 }}>All paid! 🎉</td></tr>}
                {outstanding.map(inv => (
                  <tr key={inv.id}>
                    <td style={{ fontWeight: 700, color: "#0077b6" }}>{inv.id}</td>
                    <td style={{ fontSize: 12 }}>{(customers || []).find(c => c.id === inv.customerId)?.name}</td>
                    <td style={{ fontWeight: 700, color: "#ef4444" }}>{fmt(calcTotal(inv.items) - calcPaid(inv.payments))}</td>
                    <td style={{ fontSize: 12, color: inv.dueDate && inv.dueDate < today() ? "#ef4444" : "#64748b" }}>{inv.dueDate || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
