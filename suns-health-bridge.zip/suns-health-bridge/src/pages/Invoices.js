import { useState } from 'react';
import Badge from '../components/Badge';
import { calcTotal, calcPaid, fmt, today, genId } from '../data';

export default function Invoices({ invoices, setInvoices, customers, products }) {
  const [showForm, setShowForm] = useState(false);
  const [payInvoice, setPayInvoice] = useState(null);
  const [search, setSearch] = useState("");
  const [payForm, setPayForm] = useState({ amount: "", method: "Bank Transfer", ref: "", date: today() });
  const [form, setForm] = useState({ customerId: "", dueDate: "", notes: "", items: [{ productId: "", qty: 1, unitPrice: 0 }] });

  const getStatus = (inv) => {
    const total = calcTotal(inv.items), paid = calcPaid(inv.payments);
    if (paid >= total) return "Paid";
    if (paid > 0) return "Partially Paid";
    if (inv.dueDate && inv.dueDate < today()) return "Overdue";
    return "Unpaid";
  };

  const filtered = (invoices || []).filter(inv =>
    inv.id.toLowerCase().includes(search.toLowerCase()) ||
    (customers || []).find(c => c.id === inv.customerId)?.name.toLowerCase().includes(search.toLowerCase()) ||
    getStatus(inv).toLowerCase().includes(search.toLowerCase())
  );

  const addItem    = () => setForm(f => ({ ...f, items: [...f.items, { productId: "", qty: 1, unitPrice: 0 }] }));
  const removeItem = (i) => setForm(f => ({ ...f, items: f.items.filter((_, idx) => idx !== i) }));
  const updateItem = (i, field, val) => setForm(f => {
    const items = [...f.items]; items[i] = { ...items[i], [field]: val };
    if (field === "productId") { const p = (products || []).find(p => p.id === val); if (p) items[i].unitPrice = p.sellingPrice; }
    return { ...f, items };
  });

  const saveInvoice = () => {
    if (!form.customerId || form.items.some(i => !i.productId)) return alert("Please fill all required fields.");
    const inv = {
      id: genId("INV", invoices || []), customerId: form.customerId, quotationId: null,
      date: today(), dueDate: form.dueDate, status: "Unpaid",
      items: form.items.map(i => ({ ...i, qty: Number(i.qty), unitPrice: Number(i.unitPrice) })),
      payments: [], notes: form.notes
    };
    setInvoices(is => [inv, ...(is || [])]);
    setShowForm(false);
    setForm({ customerId: "", dueDate: "", notes: "", items: [{ productId: "", qty: 1, unitPrice: 0 }] });
  };

  const recordPayment = () => {
    if (!payForm.amount) return alert("Enter payment amount");
    const amount = Number(payForm.amount);
    const total  = calcTotal(payInvoice.items), paid = calcPaid(payInvoice.payments);
    const status = (paid + amount) >= total ? "Paid" : "Partially Paid";
    setInvoices(is => (is || []).map(inv => inv.id === payInvoice.id ? { ...inv, status, payments: [...inv.payments, { ...payForm, amount }] } : inv));
    setPayInvoice(null);
    setPayForm({ amount: "", method: "Bank Transfer", ref: "", date: today() });
  };

  const del = (id) => { if (window.confirm("Delete invoice?")) setInvoices(is => (is || []).filter(i => i.id !== id)); };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div><h1 className="section-title">Invoices</h1><p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Track invoices, balances and collect payments</p></div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>+ New Invoice</button>
      </div>
      <div className="card" style={{ padding: "14px 18px", marginBottom: 16, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <input type="text" placeholder="Search invoices…" value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 280 }} />
        <div style={{ marginLeft: "auto", display: "flex", gap: 10, fontSize: 13, flexWrap: "wrap" }}>
          {["Paid", "Partially Paid", "Unpaid", "Overdue"].map(s => <span key={s}><Badge status={s} /> {(invoices || []).filter(i => getStatus(i) === s).length}</span>)}
        </div>
      </div>
      <div className="card">
        <table>
          <thead><tr><th>Invoice #</th><th>Customer</th><th>Date</th><th>Due</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map(inv => {
              const total = calcTotal(inv.items), paid = calcPaid(inv.payments), status = getStatus(inv);
              return (
                <tr key={inv.id}>
                  <td style={{ fontWeight: 700, color: "#0077b6" }}>{inv.id}</td>
                  <td>
                    <div style={{ fontWeight: 500 }}>{(customers || []).find(c => c.id === inv.customerId)?.name}</div>
                    {inv.quotationId && <div style={{ fontSize: 11, color: "#7c3aed" }}>from {inv.quotationId}</div>}
                  </td>
                  <td>{inv.date}</td>
                  <td style={{ color: inv.dueDate && inv.dueDate < today() && status !== "Paid" ? "#ef4444" : "#374151" }}>{inv.dueDate || "—"}</td>
                  <td style={{ fontWeight: 700 }}>{fmt(total)}</td>
                  <td style={{ color: "#065f46", fontWeight: 600 }}>{fmt(paid)}</td>
                  <td style={{ color: total - paid > 0 ? "#ef4444" : "#065f46", fontWeight: 700 }}>{fmt(total - paid)}</td>
                  <td><Badge status={status} /></td>
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      {status !== "Paid" && <button className="btn btn-primary btn-sm" onClick={() => setPayInvoice(inv)}>+ Pay</button>}
                      <button className="btn btn-danger btn-sm" onClick={() => del(inv.id)}>✕</button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && <tr><td colSpan={9} style={{ textAlign: "center", color: "#94a3b8", padding: 30 }}>No invoices found</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal">
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 22 }}>
              <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18 }}>New Invoice</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowForm(false)}>✕</button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 18 }}>
              <div><label>Customer *</label>
                <select value={form.customerId} onChange={e => setForm(f => ({ ...f, customerId: e.target.value }))}>
                  <option value="">Select customer…</option>
                  {(customers || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><label>Due Date</label><input type="date" value={form.dueDate} onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))} /></div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                <label style={{ marginBottom: 0 }}>Line Items *</label>
                <button className="btn btn-ghost btn-sm" onClick={addItem}>+ Add Item</button>
              </div>
              {form.items.map((item, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr auto", gap: 8, marginBottom: 8 }}>
                  <select value={item.productId} onChange={e => updateItem(i, "productId", e.target.value)}>
                    <option value="">Select product…</option>
                    {(products || []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <input type="number" placeholder="Qty" value={item.qty} min={1} onChange={e => updateItem(i, "qty", e.target.value)} />
                  <input type="number" placeholder="Price" value={item.unitPrice} onChange={e => updateItem(i, "unitPrice", e.target.value)} />
                  <button className="btn btn-danger btn-sm" onClick={() => removeItem(i)} disabled={form.items.length === 1}>✕</button>
                </div>
              ))}
              <div style={{ textAlign: "right", fontWeight: 700, color: "#0077b6", padding: "8px 0", fontSize: 15 }}>
                Total: {fmt(form.items.reduce((s, i) => s + (Number(i.qty) * Number(i.unitPrice)), 0))}
              </div>
            </div>
            <div style={{ marginBottom: 20 }}><label>Notes</label><textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Payment terms, notes…" style={{ resize: "none" }} /></div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveInvoice}>Save Invoice</button>
            </div>
          </div>
        </div>
      )}

      {payInvoice && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setPayInvoice(null)}>
          <div className="modal" style={{ maxWidth: 460 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
              <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18 }}>Record Payment</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setPayInvoice(null)}>✕</button>
            </div>
            <div style={{ background: "#f8fafc", borderRadius: 10, padding: "12px 16px", marginBottom: 20 }}>
              <div style={{ fontSize: 13, color: "#64748b" }}>{payInvoice.id} — {(customers || []).find(c => c.id === payInvoice.customerId)?.name}</div>
              <div style={{ display: "flex", gap: 20, marginTop: 8 }}>
                <div><div style={{ fontSize: 11, color: "#94a3b8" }}>Total</div><div style={{ fontWeight: 700 }}>{fmt(calcTotal(payInvoice.items))}</div></div>
                <div><div style={{ fontSize: 11, color: "#94a3b8" }}>Paid</div><div style={{ fontWeight: 700, color: "#065f46" }}>{fmt(calcPaid(payInvoice.payments))}</div></div>
                <div><div style={{ fontSize: 11, color: "#94a3b8" }}>Balance</div><div style={{ fontWeight: 700, color: "#ef4444" }}>{fmt(calcTotal(payInvoice.items) - calcPaid(payInvoice.payments))}</div></div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div><label>Amount *</label><input type="number" value={payForm.amount} onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))} placeholder="PKR" /></div>
              <div><label>Date</label><input type="date" value={payForm.date} onChange={e => setPayForm(f => ({ ...f, date: e.target.value }))} /></div>
              <div><label>Method</label>
                <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value }))}>
                  {["Bank Transfer", "Cheque", "Cash", "Online Payment"].map(m => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div><label>Reference #</label><input type="text" value={payForm.ref} onChange={e => setPayForm(f => ({ ...f, ref: e.target.value }))} placeholder="TXN / CHQ no." /></div>
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 20 }}>
              <button className="btn btn-ghost" onClick={() => setPayInvoice(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={recordPayment}>Record Payment</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
