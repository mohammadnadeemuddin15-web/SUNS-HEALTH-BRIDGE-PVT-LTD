import { useState } from 'react';
import Badge from '../components/Badge';
import { calcTotal, fmt, today, genId } from '../data';

export default function Quotations({ quotations, setQuotations, customers, products, invoices, setInvoices }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ customerId: "", validUntil: "", notes: "", items: [{ productId: "", qty: 1, unitPrice: 0 }] });

  const filtered = (quotations || []).filter(q =>
    q.id.toLowerCase().includes(search.toLowerCase()) ||
    (customers || []).find(c => c.id === q.customerId)?.name.toLowerCase().includes(search.toLowerCase())
  );

  const addItem    = () => setForm(f => ({ ...f, items: [...f.items, { productId: "", qty: 1, unitPrice: 0 }] }));
  const removeItem = (i) => setForm(f => ({ ...f, items: f.items.filter((_, idx) => idx !== i) }));
  const updateItem = (i, field, val) => setForm(f => {
    const items = [...f.items]; items[i] = { ...items[i], [field]: val };
    if (field === "productId") { const p = (products || []).find(p => p.id === val); if (p) items[i].unitPrice = p.sellingPrice; }
    return { ...f, items };
  });

  const save = () => {
    if (!form.customerId || form.items.some(i => !i.productId)) return alert("Please fill all required fields.");
    const qt = {
      id: genId("QT", quotations || []), customerId: form.customerId, date: today(),
      validUntil: form.validUntil, status: "Pending",
      items: form.items.map(i => ({ ...i, qty: Number(i.qty), unitPrice: Number(i.unitPrice) })),
      notes: form.notes, convertedToInvoice: null
    };
    setQuotations(qs => [qt, ...(qs || [])]);
    setShowForm(false);
    setForm({ customerId: "", validUntil: "", notes: "", items: [{ productId: "", qty: 1, unitPrice: 0 }] });
  };

  const convertToInvoice = (qt) => {
    if (qt.convertedToInvoice) return alert("Already converted to invoice.");
    const inv = {
      id: genId("INV", invoices || []), customerId: qt.customerId, quotationId: qt.id,
      date: today(), dueDate: "", status: "Unpaid", items: qt.items, payments: [], notes: qt.notes
    };
    setInvoices(is => [inv, ...(is || [])]);
    setQuotations(qs => (qs || []).map(q => q.id === qt.id ? { ...q, status: "Accepted", convertedToInvoice: inv.id } : q));
    alert(`✅ Invoice ${inv.id} created successfully!`);
  };

  const del = (id) => { if (window.confirm("Delete this quotation?")) setQuotations(qs => (qs || []).filter(q => q.id !== id)); };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div><h1 className="section-title">Quotations</h1><p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Create quotations and convert them to invoices</p></div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>+ New Quotation</button>
      </div>

      <div className="card" style={{ padding: "14px 18px", marginBottom: 16, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <input type="text" placeholder="Search by ID or customer…" value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 280 }} />
        <div style={{ marginLeft: "auto", display: "flex", gap: 12, fontSize: 13, color: "#64748b" }}>
          {["Pending", "Accepted", "Expired"].map(s => <span key={s}><Badge status={s} /> {(quotations || []).filter(q => q.status === s).length}</span>)}
        </div>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Quotation #</th><th>Customer</th><th>Date</th><th>Valid Until</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map(qt => (
              <tr key={qt.id}>
                <td style={{ fontWeight: 700, color: "#0077b6" }}>{qt.id}</td>
                <td>
                  <div style={{ fontWeight: 500 }}>{(customers || []).find(c => c.id === qt.customerId)?.name}</div>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>{(customers || []).find(c => c.id === qt.customerId)?.contact}</div>
                </td>
                <td>{qt.date}</td>
                <td>{qt.validUntil || "—"}</td>
                <td style={{ fontWeight: 700 }}>{fmt(calcTotal(qt.items))}</td>
                <td><Badge status={qt.status} /></td>
                <td>
                  <div style={{ display: "flex", gap: 6 }}>
                    {qt.status === "Pending" && <button className="btn btn-primary btn-sm" onClick={() => convertToInvoice(qt)}>→ Invoice</button>}
                    {qt.convertedToInvoice && <span style={{ fontSize: 11, color: "#7c3aed", fontWeight: 600 }}>{qt.convertedToInvoice}</span>}
                    <button className="btn btn-danger btn-sm" onClick={() => del(qt.id)}>✕</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} style={{ textAlign: "center", color: "#94a3b8", padding: 30 }}>No quotations found</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal">
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 22 }}>
              <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18 }}>New Quotation</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowForm(false)}>✕</button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 18 }}>
              <div><label>Customer *</label>
                <select value={form.customerId} onChange={e => setForm(f => ({ ...f, customerId: e.target.value }))}>
                  <option value="">Select customer…</option>
                  {(customers || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><label>Valid Until</label><input type="date" value={form.validUntil} onChange={e => setForm(f => ({ ...f, validUntil: e.target.value }))} /></div>
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                <label style={{ marginBottom: 0 }}>Line Items *</label>
                <button className="btn btn-ghost btn-sm" onClick={addItem}>+ Add Item</button>
              </div>
              {form.items.map((item, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr auto", gap: 8, marginBottom: 8 }}>
                  <select value={item.productId} onChange={e => updateItem(i, "productId", e.target.value)}>
                    <option value="">Select product…</option>
                    {(products || []).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <input type="number" placeholder="Qty" value={item.qty} min={1} onChange={e => updateItem(i, "qty", e.target.value)} />
                  <input type="number" placeholder="Price" value={item.unitPrice} onChange={e => updateItem(i, "unitPrice", e.target.value)} />
                  <button className="btn btn-danger btn-sm" onClick={() => removeItem(i)} disabled={form.items.length === 1}>✕</button>
                </div>
              ))}
              <div style={{ textAlign: "right", fontWeight: 700, color: "#0077b6", padding: "8px 0", fontSize: 15 }}>
                Total: {fmt(form.items.reduce((s, i) => s + (Number(i.qty) * Number(i.unitPrice)), 0))}
              </div>
            </div>
            <div style={{ marginBottom: 20 }}><label>Notes</label><textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Terms, delivery notes…" style={{ resize: "none" }} /></div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save Quotation</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
