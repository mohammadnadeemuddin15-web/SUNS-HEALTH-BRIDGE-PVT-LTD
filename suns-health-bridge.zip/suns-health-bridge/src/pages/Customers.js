import { useState } from 'react';
import { calcPaid, calcTotal, fmtShort } from '../data';

export default function Customers({ customers, setCustomers, invoices, quotations }) {
  const [showForm, setShowForm] = useState(false);
  const [editC, setEditC]       = useState(null);
  const [search, setSearch]     = useState("");
  const [form, setForm]         = useState({ name: "", contact: "", phone: "", email: "", city: "Karachi" });

  const filtered = (customers || []).filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.city.toLowerCase().includes(search.toLowerCase()) ||
    c.contact.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd  = () => { setEditC(null); setForm({ name: "", contact: "", phone: "", email: "", city: "Karachi" }); setShowForm(true); };
  const openEdit = (c) => { setEditC(c); setForm({ name: c.name, contact: c.contact, phone: c.phone, email: c.email, city: c.city }); setShowForm(true); };

  const save = () => {
    if (!form.name) return alert("Customer name required");
    if (editC) setCustomers(cs => (cs || []).map(c => c.id === editC.id ? { ...c, ...form } : c));
    else setCustomers(cs => [...(cs || []), { id: `C${String((cs || []).length + 1).padStart(3, "0")}`, ...form }]);
    setShowForm(false);
  };

  const del = (id) => { if (window.confirm("Remove customer?")) setCustomers(cs => (cs || []).filter(c => c.id !== id)); };

  const getStats = (id) => ({
    invoices: (invoices || []).filter(i => i.customerId === id).length,
    quotes:   (quotations || []).filter(q => q.customerId === id).length,
    revenue:  (invoices || []).filter(i => i.customerId === id).reduce((s, i) => s + calcPaid(i.payments), 0),
  });

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div><h1 className="section-title">Customers</h1><p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Hospital and clinic accounts</p></div>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Customer</button>
      </div>

      <div className="card" style={{ padding: "14px 18px", marginBottom: 14 }}>
        <input type="text" placeholder="Search customers…" value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 320 }} />
      </div>

      <div className="card">
        <table>
          <thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Phone</th><th>Email</th><th>City</th><th>Invoices</th><th>Revenue</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map(c => {
              const stats = getStats(c.id);
              return (
                <tr key={c.id}>
                  <td style={{ fontSize: 12, color: "#64748b", fontWeight: 600 }}>{c.id}</td>
                  <td style={{ fontWeight: 700 }}>{c.name}</td>
                  <td>{c.contact}</td>
                  <td style={{ fontSize: 12 }}>{c.phone}</td>
                  <td style={{ fontSize: 12, color: "#0077b6" }}>{c.email}</td>
                  <td><span className="tag" style={{ background: "#f0fdf4", color: "#166534" }}>{c.city}</span></td>
                  <td style={{ textAlign: "center", fontWeight: 600 }}>{stats.invoices}</td>
                  <td style={{ fontWeight: 700, color: "#059669" }}>{fmtShort(stats.revenue)}</td>
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => openEdit(c)}>✎</button>
                      <button className="btn btn-danger btn-sm" onClick={() => del(c.id)}>✕</button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && <tr><td colSpan={9} style={{ textAlign: "center", color: "#94a3b8", padding: 30 }}>No customers found</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal" style={{ maxWidth: 500 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 22 }}>
              <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18 }}>{editC ? "Edit Customer" : "Add Customer"}</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowForm(false)}>✕</button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div style={{ gridColumn: "span 2" }}><label>Hospital / Clinic Name *</label><input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div><label>Contact Person</label><input type="text" value={form.contact} onChange={e => setForm(f => ({ ...f, contact: e.target.value }))} /></div>
              <div><label>City</label><input type="text" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
              <div><label>Phone</label><input type="text" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
              <div><label>Email</label><input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 22 }}>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>{editC ? "Update" : "Add Customer"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
