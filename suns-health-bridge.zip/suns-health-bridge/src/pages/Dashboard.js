import Badge from '../components/Badge';
import { calcTotal, calcPaid, fmtShort, fmt } from '../data';

export default function Dashboard({ invoices, quotations, products, totalRevenue, totalOutstanding, lowStock, inventoryValue, customers, setTab }) {
  const stats = [
    { label: "Revenue Collected", value: fmtShort(totalRevenue),   sub: "Payments received",    color: "#0077b6", icon: "💰" },
    { label: "Outstanding",       value: fmtShort(totalOutstanding), sub: "Pending collections", color: "#f59e0b", icon: "⏳" },
    { label: "Inventory Value",   value: fmtShort(inventoryValue),  sub: "Stock at cost price",  color: "#7c3aed", icon: "📦" },
    { label: "Low Stock Alerts",  value: lowStock.length,           sub: "Items need reorder",   color: "#ef4444", icon: "⚠️" },
  ];
  const pendingQt = (quotations || []).filter(q => q.status === "Pending");

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 className="section-title">Dashboard</h1>
        <p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Live business overview for Suns Health Bridge</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 28 }}>
        {stats.map(s => (
          <div key={s.label} className="stat-card" style={{ borderLeft: `4px solid ${s.color}` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.8, textTransform: "uppercase", marginBottom: 6 }}>{s.label}</div>
                <div style={{ fontSize: 24, fontWeight: 800, color: "#0f172a", fontFamily: "'Syne',sans-serif" }}>{s.value}</div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{s.sub}</div>
              </div>
              <span style={{ fontSize: 22 }}>{s.icon}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 20 }}>
        <div className="card" style={{ padding: 22 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Recent Invoices</h3>
            <button className="btn btn-ghost btn-sm" onClick={() => setTab("invoices")}>View All</button>
          </div>
          <table>
            <thead><tr><th>Invoice</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>
              {(invoices || []).slice().reverse().slice(0, 5).map(inv => (
                <tr key={inv.id}>
                  <td style={{ fontWeight: 700, color: "#0077b6" }}>{inv.id}</td>
                  <td>{(customers || []).find(c => c.id === inv.customerId)?.name}</td>
                  <td style={{ fontWeight: 600 }}>{fmtShort(calcTotal(inv.items))}</td>
                  <td><Badge status={inv.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Pending Quotations ({pendingQt.length})</h3>
            {pendingQt.slice(0, 3).map(q => (
              <div key={q.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #f8fafc" }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "#0077b6" }}>{q.id}</div>
                  <div style={{ fontSize: 11, color: "#94a3b8" }}>{(customers || []).find(c => c.id === q.customerId)?.name}</div>
                </div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>{fmtShort(calcTotal(q.items))}</div>
              </div>
            ))}
            <button className="btn btn-ghost btn-sm" style={{ marginTop: 10, width: "100%" }} onClick={() => setTab("quotations")}>Manage Quotations</button>
          </div>

          <div className="card" style={{ padding: 20 }}>
            <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>⚠️ Low Stock ({lowStock.length})</h3>
            {lowStock.slice(0, 4).map(p => (
              <div key={p.id} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid #f8fafc" }}>
                <div style={{ fontSize: 12, fontWeight: 500 }}>{p.name.slice(0, 26)}…</div>
                <span style={{ background: "#fee2e2", color: "#991b1b", padding: "1px 7px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>{p.stock}</span>
              </div>
            ))}
            <button className="btn btn-ghost btn-sm" style={{ marginTop: 10, width: "100%" }} onClick={() => setTab("inventory")}>View Inventory</button>
          </div>
        </div>
      </div>
    </div>
  );
}
