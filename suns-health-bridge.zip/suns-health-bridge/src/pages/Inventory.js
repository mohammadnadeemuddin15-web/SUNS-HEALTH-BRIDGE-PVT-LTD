import { useState } from 'react';
import Badge from '../components/Badge';
import { fmtShort } from '../data';

export default function Inventory({ products, setProducts }) {
  const [search, setSearch]   = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editP, setEditP]     = useState(null);
  const [form, setForm]       = useState({ name: "", category: "", unit: "Pcs", stock: 0, reorderLevel: 5, costPrice: 0, sellingPrice: 0 });

  const filtered = (products || []).filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.category.toLowerCase().includes(search.toLowerCase()) ||
    p.id.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd  = () => { setEditP(null); setForm({ name: "", category: "", unit: "Pcs", stock: 0, reorderLevel: 5, costPrice: 0, sellingPrice: 0 }); setShowForm(true); };
  const openEdit = (p) => { setEditP(p); setForm({ name: p.name, category: p.category, unit: p.unit, stock: p.stock, reorderLevel: p.reorderLevel, costPrice: p.costPrice, sellingPrice: p.sellingPrice }); setShowForm(true); };

  const save = () => {
    if (!form.name || !form.category) return alert("Name and category required");
    const f2 = { ...form, stock: Number(form.stock), reorderLevel: Number(form.reorderLevel), costPrice: Number(form.costPrice), sellingPrice: Number(form.sellingPrice) };
    if (editP) setProducts(ps => (ps || []).map(p => p.id === editP.id ? { ...p, ...f2 } : p));
    else setProducts(ps => [...(ps || []), { id: `P${String((ps || []).length + 1).padStart(3, "0")}`, ...f2 }]);
    setShowForm(false);
  };

  const del = (id) => { if (window.confirm("Remove product?")) setProducts(ps => (ps || []).filter(p => p.id !== id)); };

  const lowCount = (products || []).filter(p => p.stock <= p.reorderLevel).length;
  const totalVal = (products || []).reduce((s, p) => s + p.stock * p.costPrice, 0);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div><h1 className="section-title">Inventory</h1><p style={{ color: "#64748b", fontSize: 14, marginTop: 4 }}>Medical device stock, pricing and reorder alerts</p></div>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Product</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 20 }}>
        {[
          { label: "Total Products", value: (products || []).length, color: "#0077b6" },
          { label: "Stock Value",    value: fmtShort(totalVal),      color: "#7c3aed" },
          { label: "Low Stock",      value: lowCount,                 color: "#ef4444" },
          { label: "Categories",     value: [...new Set((products || []).map(p => p.category))].length, color: "#059669" },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ borderLeft: `4px solid ${s.color}` }}>
            <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8 }}>{s.label}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#0f172a", fontFamily: "'Syne',sans-serif", marginTop: 4 }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="card" style={{ padding: "14px 18px", marginBottom: 14 }}>
        <input type="text" placeholder="Search products…" value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 360 }} />
      </div>

      <div className="card">
        <table>
          <thead><tr><th>ID</th><th>Product</th><th>Category</th><th>Unit</th><th>Stock</th><th>Reorder</th><th>Cost (PKR)</th><th>Selling (PKR)</th><th>Margin</th><th>Alert</th><th>Actions</th></tr></thead>
          <tbody>
            {filtered.map(p => {
              const isLow  = p.stock <= p.reorderLevel;
              const margin = p.sellingPrice > 0 ? (((p.sellingPrice - p.costPrice) / p.sellingPrice) * 100).toFixed(0) : 0;
              return (
                <tr key={p.id}>
                  <td style={{ fontSize: 12, color: "#64748b", fontWeight: 600 }}>{p.id}</td>
                  <td style={{ fontWeight: 600 }}>{p.name}</td>
                  <td><span className="tag" style={{ background: "#dbeafe", color: "#1e40af" }}>{p.category}</span></td>
                  <td>{p.unit}</td>
                  <td style={{ fontWeight: 700, color: isLow ? "#ef4444" : "#059669" }}>{p.stock}</td>
                  <td style={{ color: "#64748b" }}>{p.reorderLevel}</td>
                  <td>{Number(p.costPrice).toLocaleString()}</td>
                  <td>{Number(p.sellingPrice).toLocaleString()}</td>
                  <td><span style={{ color: margin > 20 ? "#059669" : "#f59e0b", fontWeight: 700 }}>{margin}%</span></td>
                  <td>{isLow ? <Badge status="Overdue" /> : <span className="tag" style={{ background: "#d1fae5", color: "#065f46" }}>OK</span>}</td>
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => openEdit(p)}>✎</button>
                      <button className="btn btn-danger btn-sm" onClick={() => del(p.id)}>✕</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal" style={{ maxWidth: 560 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 22 }}>
              <h2 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18 }}>{editP ? "Edit Product" : "Add Product"}</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowForm(false)}>✕</button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div style={{ gridColumn: "span 2" }}><label>Product Name *</label><input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
              <div><label>Category *</label><input type="text" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} /></div>
              <div><label>Unit</label>
                <select value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))}>
                  {["Pcs", "Box", "Pack", "Set", "Kit", "Pair"].map(u => <option key={u}>{u}</option>)}
                </select>
              </div>
              <div><label>Current Stock</label><input type="number" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} min={0} /></div>
              <div><label>Reorder Level</label><input type="number" value={form.reorderLevel} onChange={e => setForm(f => ({ ...f, reorderLevel: e.target.value }))} min={0} /></div>
              <div><label>Cost Price (PKR)</label><input type="number" value={form.costPrice} onChange={e => setForm(f => ({ ...f, costPrice: e.target.value }))} min={0} /></div>
              <div><label>Selling Price (PKR)</label><input type="number" value={form.sellingPrice} onChange={e => setForm(f => ({ ...f, sellingPrice: e.target.value }))} min={0} /></div>
            </div>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 22 }}>
              <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>{editP ? "Update" : "Add Product"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
