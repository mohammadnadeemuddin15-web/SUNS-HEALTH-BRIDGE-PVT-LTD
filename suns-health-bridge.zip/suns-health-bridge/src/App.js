import { useState, useMemo, useEffect } from 'react';
import { useLocalStorage }  from './hooks/useLocalStorage';
import { globalStyles }     from './styles';
import { defaultProducts, defaultCustomers, defaultQuotations, defaultInvoices, calcTotal, calcPaid, fmtShort, nowTs } from './data';
import Dashboard   from './pages/Dashboard';
import Quotations  from './pages/Quotations';
import Invoices    from './pages/Invoices';
import Inventory   from './pages/Inventory';
import Payments    from './pages/Payments';
import Customers   from './pages/Customers';

export default function App() {
  const [tab, setTab] = useState('dashboard');
  const [products,   setProducts]   = useLocalStorage('suns-products',   defaultProducts);
  const [customers,  setCustomers]  = useLocalStorage('suns-customers',  defaultCustomers);
  const [quotations, setQuotations] = useLocalStorage('suns-quotations', defaultQuotations);
  const [invoices,   setInvoices]   = useLocalStorage('suns-invoices',   defaultInvoices);
  const [syncMsg,    setSyncMsg]    = useState('');

  // Inject global styles once
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = globalStyles;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const totalRevenue     = useMemo(() => (invoices||[]).reduce((s,inv) => s + calcPaid(inv.payments), 0), [invoices]);
  const totalOutstanding = useMemo(() => (invoices||[]).reduce((s,inv) => s + (calcTotal(inv.items) - calcPaid(inv.payments)), 0), [invoices]);
  const lowStock         = useMemo(() => (products||[]).filter(p => p.stock <= p.reorderLevel), [products]);
  const inventoryValue   = useMemo(() => (products||[]).reduce((s,p) => s + p.stock * p.costPrice, 0), [products]);

  // Simulated "sync" — in a real multi-user setup replace with a cloud DB fetch
  const handleSync = () => {
    setSyncMsg('✓ Data up to date — ' + nowTs());
    setTimeout(() => setSyncMsg(''), 3000);
  };

  const nav = [
    { id: 'dashboard',  label: 'Dashboard',  icon: '⊞' },
    { id: 'quotations', label: 'Quotations', icon: '📋' },
    { id: 'invoices',   label: 'Invoices',   icon: '🧾' },
    { id: 'inventory',  label: 'Inventory',  icon: '📦' },
    { id: 'payments',   label: 'Payments',   icon: '💳' },
    { id: 'customers',  label: 'Customers',  icon: '🏥' },
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f0f4f8' }}>
      {/* ── Sidebar ── */}
      <aside style={{ width: 220, minHeight: '100vh', background: 'white', borderRight: '1px solid #f1f5f9', padding: '24px 14px', display: 'flex', flexDirection: 'column', gap: 4, flexShrink: 0 }}>
        <div style={{ padding: '0 6px 20px' }}>
          <div style={{ fontFamily: "'Syne',sans-serif", fontSize: 17, fontWeight: 800, color: '#0077b6' }}>SUNS</div>
          <div style={{ fontSize: 10, color: '#94a3b8', fontWeight: 600, letterSpacing: 1 }}>HEALTH BRIDGE</div>
          <div style={{ marginTop: 8, height: 2, width: 32, background: 'linear-gradient(90deg,#0077b6,#00b4d8)', borderRadius: 2 }} />
        </div>

        {nav.map(n => (
          <div key={n.id} className={`nav-item ${tab === n.id ? 'active' : ''}`} onClick={() => setTab(n.id)}>
            <span style={{ fontSize: 16 }}>{n.icon}</span>{n.label}
          </div>
        ))}

        <div style={{ marginTop: 'auto', padding: '14px 6px 0', borderTop: '1px solid #f1f5f9' }}>
          <button
            className="btn btn-ghost btn-sm"
            style={{ width: '100%', marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
            onClick={handleSync}
          >
            ↻ Refresh
          </button>
          {syncMsg && <div className="sync-toast" style={{ fontSize: 11, color: '#059669', textAlign: 'center', fontWeight: 600 }}>{syncMsg}</div>}
          <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 6 }}>Suns Health Bridge v1.0</div>
          <div style={{ fontSize: 10, color: '#cbd5e1', marginTop: 2 }}>Medical Device Importer · Karachi</div>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <main style={{ flex: 1, padding: '28px 32px', overflowY: 'auto' }}>
        {tab === 'dashboard'  && <Dashboard   invoices={invoices} quotations={quotations} products={products} totalRevenue={totalRevenue} totalOutstanding={totalOutstanding} lowStock={lowStock} inventoryValue={inventoryValue} customers={customers} setTab={setTab} />}
        {tab === 'quotations' && <Quotations  quotations={quotations} setQuotations={setQuotations} customers={customers} products={products} invoices={invoices} setInvoices={setInvoices} />}
        {tab === 'invoices'   && <Invoices    invoices={invoices} setInvoices={setInvoices} customers={customers} products={products} />}
        {tab === 'inventory'  && <Inventory   products={products} setProducts={setProducts} />}
        {tab === 'payments'   && <Payments    invoices={invoices} customers={customers} />}
        {tab === 'customers'  && <Customers   customers={customers} setCustomers={setCustomers} invoices={invoices} quotations={quotations} />}
      </main>
    </div>
  );
}
