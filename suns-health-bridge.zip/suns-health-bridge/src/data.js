// ─── Default Seed Data ─────────────────────────────────────────────────────────

export const defaultProducts = [
  { id: "P001", name: "Digital Blood Pressure Monitor", category: "Diagnostic", unit: "Pcs", stock: 45, reorderLevel: 10, costPrice: 2800, sellingPrice: 4500 },
  { id: "P002", name: "Pulse Oximeter (Fingertip)",     category: "Monitoring", unit: "Pcs", stock: 120, reorderLevel: 20, costPrice: 850,  sellingPrice: 1500 },
  { id: "P003", name: "Surgical Gloves (Box/100)",      category: "PPE",        unit: "Box", stock: 8,   reorderLevel: 15, costPrice: 1200, sellingPrice: 1800 },
  { id: "P004", name: "ECG Machine 12-Lead",            category: "Cardiac",    unit: "Pcs", stock: 5,   reorderLevel: 2,  costPrice: 85000, sellingPrice: 125000 },
  { id: "P005", name: "Infusion Pump",                  category: "ICU Equipment", unit: "Pcs", stock: 12, reorderLevel: 3, costPrice: 45000, sellingPrice: 68000 },
  { id: "P006", name: "Nebulizer Machine",              category: "Respiratory", unit: "Pcs", stock: 30, reorderLevel: 8,  costPrice: 3200, sellingPrice: 5200 },
  { id: "P007", name: "Surgical Mask N95 (Box/20)",     category: "PPE",        unit: "Box", stock: 200, reorderLevel: 50, costPrice: 800,  sellingPrice: 1200 },
  { id: "P008", name: "Ultrasound Machine Portable",    category: "Imaging",    unit: "Pcs", stock: 3,   reorderLevel: 1,  costPrice: 320000, sellingPrice: 480000 },
];

export const defaultCustomers = [
  { id: "C001", name: "Aga Khan Hospital",        contact: "Dr. Rashid", phone: "021-3486-1234", email: "procurement@akh.pk",     city: "Karachi" },
  { id: "C002", name: "Liaquat National Hospital",contact: "Mr. Farhan", phone: "021-3412-5678", email: "stores@lnh.edu.pk",      city: "Karachi" },
  { id: "C003", name: "South City Hospital",      contact: "Ms. Sadia",  phone: "021-3521-9876", email: "purchase@sch.pk",        city: "Karachi" },
  { id: "C004", name: "Indus Hospital",           contact: "Dr. Amna",   phone: "021-3511-4444", email: "medical@indus.pk",       city: "Karachi" },
  { id: "C005", name: "Ziauddin Hospital",        contact: "Mr. Khalid", phone: "021-3866-2200", email: "supplies@ziauddin.pk",   city: "Karachi" },
];

export const defaultQuotations = [
  {
    id: "QT-2025-001", customerId: "C001", date: "2025-05-10", validUntil: "2025-06-10",
    status: "Accepted",
    items: [{ productId: "P004", qty: 2, unitPrice: 125000 }, { productId: "P005", qty: 3, unitPrice: 68000 }],
    notes: "Bulk order for new ICU wing", convertedToInvoice: "INV-2025-001"
  },
  {
    id: "QT-2025-002", customerId: "C002", date: "2025-05-18", validUntil: "2025-06-18",
    status: "Pending",
    items: [{ productId: "P002", qty: 50, unitPrice: 1500 }, { productId: "P006", qty: 10, unitPrice: 5200 }],
    notes: "", convertedToInvoice: null
  },
  {
    id: "QT-2025-003", customerId: "C003", date: "2025-05-20", validUntil: "2025-06-20",
    status: "Pending",
    items: [{ productId: "P001", qty: 20, unitPrice: 4500 }, { productId: "P007", qty: 30, unitPrice: 1200 }],
    notes: "Confirm delivery timeline", convertedToInvoice: null
  },
];

export const defaultInvoices = [
  {
    id: "INV-2025-001", customerId: "C001", quotationId: "QT-2025-001",
    date: "2025-05-12", dueDate: "2025-06-12", status: "Partially Paid",
    items: [{ productId: "P004", qty: 2, unitPrice: 125000 }, { productId: "P005", qty: 3, unitPrice: 68000 }],
    payments: [{ date: "2025-05-15", amount: 200000, method: "Bank Transfer", ref: "TXN-8821" }],
    notes: "ICU equipment supply"
  },
  {
    id: "INV-2025-002", customerId: "C005", quotationId: null,
    date: "2025-05-14", dueDate: "2025-06-14", status: "Paid",
    items: [{ productId: "P003", qty: 20, unitPrice: 1800 }, { productId: "P007", qty: 50, unitPrice: 1200 }],
    payments: [{ date: "2025-05-20", amount: 96000, method: "Cheque", ref: "CHQ-4412" }],
    notes: ""
  },
  {
    id: "INV-2025-003", customerId: "C002", quotationId: null,
    date: "2025-05-21", dueDate: "2025-06-21", status: "Unpaid",
    items: [{ productId: "P001", qty: 15, unitPrice: 4500 }, { productId: "P002", qty: 30, unitPrice: 1500 }],
    payments: [], notes: "Net 30 terms"
  },
];

// ─── Helpers ───────────────────────────────────────────────────────────────────
export const calcTotal = (items) => items.reduce((s, i) => s + i.qty * i.unitPrice, 0);
export const calcPaid  = (pmts)  => pmts.reduce((s, p) => s + p.amount, 0);
export const fmt       = (n) => "PKR " + Number(n).toLocaleString("en-PK");
export const fmtShort  = (n) => {
  if (n >= 1000000) return "PKR " + (n / 1000000).toFixed(1) + "M";
  if (n >= 1000)    return "PKR " + (n / 1000).toFixed(0) + "K";
  return "PKR " + n;
};
export const today  = () => new Date().toISOString().slice(0, 10);
export const nowTs  = () => new Date().toLocaleTimeString("en-PK", { hour: "2-digit", minute: "2-digit" });
export const genId  = (prefix, list) => `${prefix}-2025-${String(list.length + 1).padStart(3, "0")}`;

export const statusColors = {
  Paid:             { bg: "#d1fae5", text: "#065f46" },
  Unpaid:           { bg: "#fee2e2", text: "#991b1b" },
  "Partially Paid": { bg: "#fef3c7", text: "#92400e" },
  Overdue:          { bg: "#fce7f3", text: "#9d174d" },
  Accepted:         { bg: "#d1fae5", text: "#065f46" },
  Pending:          { bg: "#dbeafe", text: "#1e40af" },
  Expired:          { bg: "#f3f4f6", text: "#6b7280" },
};
