import { statusColors } from '../data';

export default function Badge({ status }) {
  const c = statusColors[status] || { bg: "#f3f4f6", text: "#374151" };
  return (
    <span style={{
      background: c.bg, color: c.text,
      padding: "2px 10px", borderRadius: 20,
      fontSize: 11, fontWeight: 700, letterSpacing: 0.5
    }}>
      {status?.toUpperCase()}
    </span>
  );
}
