export const globalStyles = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Syne:wght@700;800&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'DM Sans', sans-serif; background: #f0f4f8; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: #f0f4f8; }
  ::-webkit-scrollbar-thumb { background: #00b4d8; border-radius: 4px; }
  input, select, textarea { font-family: 'DM Sans', sans-serif; }

  .nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 11px 18px; border-radius: 10px; cursor: pointer;
    font-size: 14px; font-weight: 500; color: #64748b; transition: all 0.2s;
  }
  .nav-item:hover { background: rgba(0,180,216,0.08); color: #00b4d8; }
  .nav-item.active {
    background: linear-gradient(135deg, #0077b6, #00b4d8);
    color: white; box-shadow: 0 4px 12px rgba(0,180,216,0.35);
  }

  .card {
    background: white; border-radius: 14px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04);
  }
  .stat-card {
    background: white; border-radius: 14px; padding: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  }

  .btn {
    padding: 9px 18px; border-radius: 8px; border: none; cursor: pointer;
    font-size: 13px; font-weight: 600; font-family: 'DM Sans', sans-serif; transition: all 0.2s;
  }
  .btn-primary {
    background: linear-gradient(135deg, #0077b6, #00b4d8);
    color: white; box-shadow: 0 3px 10px rgba(0,180,216,0.3);
  }
  .btn-primary:hover { box-shadow: 0 5px 16px rgba(0,180,216,0.45); transform: translateY(-1px); }
  .btn-ghost { background: transparent; color: #64748b; border: 1.5px solid #e2e8f0; }
  .btn-ghost:hover { border-color: #00b4d8; color: #00b4d8; }
  .btn-danger { background: #fee2e2; color: #991b1b; border: none; }
  .btn-sm { padding: 5px 12px; font-size: 12px; }

  table { width: 100%; border-collapse: collapse; }
  th {
    text-align: left; padding: 10px 14px; font-size: 11px; font-weight: 700;
    color: #94a3b8; text-transform: uppercase; letter-spacing: 0.8px;
    border-bottom: 1px solid #f1f5f9; background: #fafbfc;
  }
  td { padding: 12px 14px; font-size: 13px; color: #374151; border-bottom: 1px solid #f8fafc; vertical-align: middle; }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: #fafbfe; }

  input[type=text], input[type=number], input[type=date], input[type=email], select, textarea {
    width: 100%; padding: 9px 12px; border: 1.5px solid #e2e8f0;
    border-radius: 8px; font-size: 13px; color: #374151; outline: none; transition: border-color 0.2s;
  }
  input:focus, select:focus, textarea:focus {
    border-color: #00b4d8; box-shadow: 0 0 0 3px rgba(0,180,216,0.1);
  }
  label { font-size: 12px; font-weight: 600; color: #64748b; display: block; margin-bottom: 5px; }

  .modal-overlay {
    position: fixed; inset: 0; background: rgba(0,0,0,0.5);
    z-index: 999; display: flex; align-items: center; justify-content: center; padding: 20px;
  }
  .modal {
    background: white; border-radius: 16px; padding: 28px;
    max-width: 720px; width: 100%; max-height: 90vh; overflow-y: auto;
  }
  .section-title { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; color: #0f172a; }
  .tag { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes fadein { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  .sync-toast { animation: fadein 0.3s ease; }
`;
